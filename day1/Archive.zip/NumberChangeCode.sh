#!/bin/bash
#To compile: chmod u+x epiFormater.sh
#To run, issue: ./epiFormater.sh 

set -o errexit -o nounset -o xtrace
#set -o errexit -o nounset


#this code assumes you are working in a directory that only has the files of interest!
for files in FILE.NAME
do
	echo "$files"
	
	#remove header and ID columns and make separate
	awk '{print $1}' $files > $files.animalIDs.txt
	#cut -d\  -f2- $files > $files.tmp #cut -f 2 $files > $files.tmp #figure out how to use cut to remove first column
	awk '{$1=""; print $0}' $files > $files.tmp
	head -1 $files.tmp > $files.MarkerHeader.txt
	tail -n +2 $files.tmp > $files.tmp.tmp
	
	#Fix the GenSel format for EpiSNP
	sed -e 's/0.00/1/g' -e 's/1.00/2/g' -e 's/2.00/3/g'  $files.tmp.tmp > tmp
	sed -e 's/[0-9]\.[0-9]\{2\}/0/g' tmp > $files.fixed.txt
	rm tmp $files.tmp.tmp
	
	echo "COMPLETE!"
done
