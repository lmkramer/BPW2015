#!/usr/bin/perl

use warnings;
use strict;

my $filename = $ARGV[0];
my @fileArray = @_;
my $count = 0;

open(FILENAME, "<$filename");
while(my $input = <FILENAME>)
{
	chomp $input;
	$fileArray[$count] = $input;
	$count++;
}

for ($i=0;$1<@fileArray;i++)
{
	for($j=$i+1;$j<@fileArray;$j++)
	{
		@iSplit = split(/_/, $fileArray[$i]);
		@jSplit = split(/_/, $fileArray[$j]);
		
		if(!($iSplit[0] eq $jSplit[0]))
		{
			print $array[$i]."\t".$fileArray[$j];
		}
	}
}






perl myscript.pl infile > outfile